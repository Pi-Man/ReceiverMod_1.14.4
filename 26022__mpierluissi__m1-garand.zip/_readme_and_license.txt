Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - MPierluissi ( https://freesound.org/people/MPierluissi/ )

You can find this pack online at: https://freesound.org/people/MPierluissi/packs/26022/

License details
---------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 460859__mpierluissi__30cal-bullet-casing.wav
    * url: https://freesound.org/s/460859/
    * license: Creative Commons 0
  * 460857__mpierluissi__garand-slide-back.wav
    * url: https://freesound.org/s/460857/
    * license: Creative Commons 0
  * 460856__mpierluissi__garand-slide-forward.wav
    * url: https://freesound.org/s/460856/
    * license: Creative Commons 0
  * 460855__mpierluissi__garand-reload.wav
    * url: https://freesound.org/s/460855/
    * license: Creative Commons 0
  * 460854__mpierluissi__garand-reload2.wav
    * url: https://freesound.org/s/460854/
    * license: Creative Commons 0
  * 460853__mpierluissi__garand-clip-drop.wav
    * url: https://freesound.org/s/460853/
    * license: Creative Commons 0
  * 460852__mpierluissi__garand-dry-fire.wav
    * url: https://freesound.org/s/460852/
    * license: Creative Commons 0
  * 460851__mpierluissi__garand-gunshot.wav
    * url: https://freesound.org/s/460851/
    * license: Creative Commons 0
  * 460850__mpierluissi__garand-handling.wav
    * url: https://freesound.org/s/460850/
    * license: Creative Commons 0
  * 460848__mpierluissi__garand-clip-eject.wav
    * url: https://freesound.org/s/460848/
    * license: Creative Commons 0
  * 460847__mpierluissi__garand-clip-eject2.wav
    * url: https://freesound.org/s/460847/
    * license: Creative Commons 0
  * 460846__mpierluissi__garand-clip-eject3.wav
    * url: https://freesound.org/s/460846/
    * license: Creative Commons 0


